package java.lang;

@SJC.IgnoreUnit
public @interface Override {
}
