package rte;
import rte.*;
import java.lang.*;

public class SArray
{
	public final int length = 0, _r_dim = 0, _r_stdType = 0;
	public final Object _r_unitType = null;
}