package kernel.memory;

public class EmptyObject {
}
