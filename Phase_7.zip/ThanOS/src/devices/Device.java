package devices;

public abstract class Device {
    public abstract void handleIRQ(int no);
}
