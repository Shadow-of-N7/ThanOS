package devices;

public class KeyStates {
    public static boolean leftArrowPressed = false;
    public static boolean rightArrowPressed = false;
}
