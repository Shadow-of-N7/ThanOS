package devices;

public class GraphicsDriver {
    protected int textCols;
    protected int textLines;
    protected int cursorX;
    protected int cursorY;
}
