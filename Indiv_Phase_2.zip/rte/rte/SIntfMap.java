package rte;
import rte.*;
import java.lang.*;

public class SIntfMap
{
	public SIntfDesc owner;
	public SIntfMap next;
}
