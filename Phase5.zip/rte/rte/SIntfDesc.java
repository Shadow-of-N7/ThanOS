package rte;
import rte.*;
import java.lang.*;

public class SIntfDesc
{
}
