package rte;
import rte.*;
import java.lang.*;

public class SClassDesc
{
	public SClassDesc parent;
	public SIntfMap implementations;
}
