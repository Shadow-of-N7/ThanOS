package java.lang;
import rte.*;

public class Object
{
	public SClassDesc _r_type=null;
	public final Object _r_next=null;
	public final int _r_relocEntries=0, _r_scalarSize=0;
}
