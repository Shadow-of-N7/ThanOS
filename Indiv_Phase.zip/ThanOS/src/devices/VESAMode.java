package devices;

public class VESAMode {
  public VESAMode nextMode;
  boolean graphical;
  public int modeNr, lfbAddress;
  public int xRes, yRes, colDepth;
}
