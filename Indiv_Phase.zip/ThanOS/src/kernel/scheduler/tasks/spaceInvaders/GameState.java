package kernel.scheduler.tasks.spaceInvaders;

public class GameState {
    public static final byte READY = 0;
    public static final byte PLAYING = 1;
    public static final byte DEAD = 2;
    public static final byte WIN = 3;
    public static final byte OFF = 4;
}
