package java.lang;

@SJC.IgnoreUnit
public class FLASH {

}
